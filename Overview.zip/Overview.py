# This is the Overview section and it provide the collection of quiz question available in the database
# It has option to create the New Collection of quiz and it creates the equivalent collection in the database
import streamlit as st
import pandas as pd
from App.Unified import get_db, get_headings, add_n_cards_to_anki_collection
import random
st.set_page_config(initial_sidebar_state="collapsed")
hide_pages = """
    <style>
    [data-testid="stSidebarNav"] {display: none;}
    </style>
"""
st.markdown(hide_pages, unsafe_allow_html=True)
mydb = get_db()
selected_collection = mydb["test-tagging"]
anki_collection = mydb["anki_collection"]

headings = get_headings(mydb)
st.subheader("Hierarchical Tagging")
# Extract unique topics and subtopics
topics = ["None"] + sorted({h["topic"] for h in headings if "topic" in h})
subtopics_by_topic = {}
for h in headings:
    if "topic" in h and "subtopic" in h:
        subtopics_by_topic.setdefault(h["topic"], set()).update(h["subtopic"] if isinstance(h["subtopic"], list) else [h["subtopic"]])

selected_topic = st.radio("Select Topic:", topics) if topics else None
selected_subtopic = None
if selected_topic and selected_topic != "None":
    subtopics = ["None"] + sorted(subtopics_by_topic.get(selected_topic, []))
    selected_subtopic = st.radio("Select Subtopic:", subtopics, index=0)
else:
    selected_subtopic = "None"


#st.info(f"Collection '{selected_collection}' has {count} questions.")
st.session_state.hierarchy_tags = [selected_topic, selected_subtopic] if selected_topic and selected_subtopic else [None, None]
# Action buttons
#st.write("Current hierarchy tags:", st.session_state.hierarchy_tags)
col1,col2, col3, col4, col5 = st.columns(5)
with col1:
    if st.button("Upload"):
        st.session_state.selected_collection = selected_collection
        st.switch_page("pages/Load_Questions.py")
with col2:
    if st.button("Goto Anki Quiz"):
        st.session_state.selected_collection = selected_collection
        st.switch_page("pages/Anki-Quiz.py")
with col3:
    if st.button("Add Cards to Anki"):
        count = add_n_cards_to_anki_collection(selected_collection, st.session_state.hierarchy_tags)
        st.success(f"Added {count} cards from '{st.session_state.hierarchy_tags}' to Anki collection with anki=0.")
with col4:
    if st.button("List"):
        st.session_state.selected_collection = selected_collection
        st.switch_page("pages/List_Question.py")
with col5:
    if st.button("Start Quiz"):
        st.session_state.selected_collection = selected_collection
        st.switch_page("pages/Load_Quiz.py")
